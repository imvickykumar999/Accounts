This package has Multiple Customers record.
